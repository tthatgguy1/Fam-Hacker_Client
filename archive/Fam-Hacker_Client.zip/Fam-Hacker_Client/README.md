# Termux-Torrent
A simple bash tool that will allow you to **Download anything using torrent with Termux.**

The script will allow you to download torrent data without installing any UTorrent or bit torrent application in you phone. This is a light weight alternative to the torrent applications. It Saves your RAM, does not run in background and works perfectly.

### Me:
Author👨‍💻: https://github.com/tthatgguy1 <br>

Website🌎: www.Learntermux.tech <br>

<br>
<br>

### Installation ⬇:

`pkg update` <br>

`pkg install git` <br>

`git clone https://github.com/tthatgguy1/Fam-Hacker_Client.git` <br>

`cd Termux-Torrent` <br>

`bash install.sh` <br>



<br>
<br>

### Use 🏃‍♂️:

1. Download any torrent file from web.<br>
2. Just open the .torrent file.  <br>
3. Click on Edit. <br>
4. The file will start downloading.

<br>
<br>

### Complete Guide with one line installation 🔗:
Read This post for installation and usage, I have explained everything using screenshots.


####    What is Termux-Torrent?    ####
<Whenever you want to download any movie or file using torrent, you first have to install U torrent or bit torrent application from the play store, and these are called torrent clients. The torrent clients help you to download the torrent data using . torrent file. These applications take space on your phone, auto start and make your phone slow, and they even show annoying ads. Since you are a termux user, there is a better alternative to download data from torrent and that is Termux-Torrent tool. This tool is going to help to download any .torrent file data with just 3 clicks.>

<Termux-Torrent tool is really lightweight and works perfectly. Just install this tool and your termux have a capability of a torrent client. You can use your termux like you normally do but when ever you will open any .torrent file in your phone, it will open in termux-torrent downloader and termux will start downloading the file automatically. 

<Step 1 :>
<Open any torrent movie site or file downloading site and download the .torrent file. and just press on open button as after downloading the .torrent file is complete.>

<Step 2 :>
<Now the file will open in a window, You just have to press on Edit button and that it.>

<Step 3 :>
<Now the downloading will start automatically, you just have to minimize the termux, and it will close after the download complete. You can see the download progress and estimated download time as shown in the below picture.>

<Conclusion:>
<Termux-Torrent is a tool that I have created so that I can use my termux application as a torrent downloader also. If you remember, I have created one more tool called Termux-YTD and will help you to download YouTube videos with termux. I am creating and collecting these kinds of tools, so we can replace as much application with termux as possible and use everything in one simple termux. If you have any tool idea that matches with this one, then comment the idea and I will try to make a tool for it. For now thanks for reading guys, and as always Stay Ethical 👾.>






<br>
<br>

### Features:
- Works with any website as long as you can download .torrent file from it.
- Download any Video in Just 2 Click.
- No ads and no purchase.
- Fast download.

<br>
<br>

### TODO 📝:
- Support for magnet links
